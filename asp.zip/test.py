s = [1, 2, 3][0]
print(s)

x = 17%3
print(x)

x = 100%(-2%(+2*5)+18)
print(x)

x = [1, 2, 3]
y = [1, 2, 3]
print(x==y)

if False or True or 114 or "?":
    print("YAY")
