Backup filer for INF2100. Slettes etter hver innlevering.
